import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'Ass2';
  userName='';

  allowNewUser = false;
  userCreationStatus: string;
  onAddUser() {
    this.userCreationStatus = 'USER was created => Name is ' + this.userName;
  }

  constructor() {
    setTimeout(() => {
      this.allowNewUser = true;
    }, 2000);
  }

}
